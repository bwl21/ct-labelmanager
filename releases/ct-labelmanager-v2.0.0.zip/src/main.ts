import type { Person } from './utils/ct-types';
import { churchtoolsClient } from '@churchtools/churchtools-client';

// Only import reset.css in development mode to keep the production bundle small
// and to simulate CT environment
if (import.meta.env.MODE === 'development') {
  import('./utils/reset.css');
}

declare const window: Window & typeof globalThis & {
  settings: {
    base_url?: string;
  };
  Vue: any;
};

const baseUrl = window.settings?.base_url ?? import.meta.env.VITE_BASE_URL;
churchtoolsClient.setBaseUrl(baseUrl);

const username = import.meta.env.VITE_USERNAME;
const password = import.meta.env.VITE_PASSWORD;

if (import.meta.env.MODE === 'development' && username && password) {
  await churchtoolsClient.post('/login', { username, password });
}

const KEY = import.meta.env.VITE_KEY;
export { KEY };

// Initialize the Vue application
const { createApp, ref, reactive, computed, onMounted } = window.Vue;

createApp({
  setup() {
    const isAuthenticated = ref(false);
    const currentUser = ref('');
    const isLoading = ref(false);
    const isLoadingTags = ref(false);
    const isSaving = ref(false);
    const loginError = ref('');
    const loginStatus = ref('');
    const tagError = ref('');
    const selectedType = ref('person');
    const showCreateForm = ref(false);
    const editingTag = ref(null);
    const apiToken = ref('');
    const personId = ref(null);
    const selectedTags = ref([]);
    const prefixFilter = ref('');
    const bulkColor = ref('');
    const isBulkOperating = ref(false);
    const showBulkColorDropdown = ref(false);
    const showTagColorDropdown = ref(false);
    const showColorPicker = ref(false);
    const colorPickerTarget = ref(''); // 'bulk' or 'tag'
    const selectedColorInPicker = ref('');
    const sortField = ref('name');
    const sortDirection = ref('asc');
    const toasts = ref([]);
    
    const loginForm = reactive({
      baseUrl: baseUrl || 'https://your-church.church.tools',
      username: '',
      password: ''
    });
    
    const tagForm = reactive({
      name: '',
      description: '',
      color: ''
    });
    
    const tags = ref([]);
    
    const allSelected = computed(() => 
      tags.value.length > 0 && selectedTags.value.length === tags.value.length
    );
    
    const sortedTags = computed(() => {
      if (!tags.value.length) return [];
      
      return [...tags.value].sort((a, b) => {
        let aVal = a[sortField.value];
        let bVal = b[sortField.value];
        
        // Handle null/undefined values
        if (aVal == null) aVal = '';
        if (bVal == null) bVal = '';
        
        // Convert to string for comparison
        aVal = String(aVal).toLowerCase();
        bVal = String(bVal).toLowerCase();
        
        if (sortDirection.value === 'asc') {
          return aVal.localeCompare(bVal);
        } else {
          return bVal.localeCompare(aVal);
        }
      });
    });
    
    // Color options for tags
    const colorOptions = computed(() => {
      return [
        { value: '', label: 'Select a color', hex: '' },
        { value: 'parent', label: 'Parent', hex: '#6b7280' },
        { value: 'default', label: 'Default', hex: '#6b7280' },
        { value: 'accent', label: 'Accent', hex: '#007cba' },
        { value: 'amber', label: 'Amber', hex: '#f59e0b' },
        { value: 'basic', label: 'Basic', hex: '#6b7280' },
        { value: 'black', label: 'Black', hex: '#000000' },
        { value: 'blue', label: 'Blue', hex: '#3b82f6' },
        { value: 'critical', label: 'Critical', hex: '#dc2626' },
        { value: 'constructive', label: 'Constructive', hex: '#16a34a' },
        { value: 'destructive', label: 'Destructive', hex: '#dc2626' },
        { value: 'cyan', label: 'Cyan', hex: '#06b6d4' },
        { value: 'danger', label: 'Danger', hex: '#dc2626' },
        { value: 'emerald', label: 'Emerald', hex: '#10b981' },
        { value: 'error', label: 'Error', hex: '#dc2626' },
        { value: 'fuchsia', label: 'Fuchsia', hex: '#d946ef' },
        { value: 'gray', label: 'Gray', hex: '#6b7280' },
        { value: 'green', label: 'Green', hex: '#16a34a' },
        { value: 'indigo', label: 'Indigo', hex: '#6366f1' },
        { value: 'info', label: 'Info', hex: '#3b82f6' },
        { value: 'lime', label: 'Lime', hex: '#84cc16' },
        { value: 'magic', label: 'Magic', hex: '#8b5cf6' },
        { value: 'orange', label: 'Orange', hex: '#f97316' },
        { value: 'pink', label: 'Pink', hex: '#ec4899' },
        { value: 'purple', label: 'Purple', hex: '#a855f7' },
        { value: 'red', label: 'Red', hex: '#dc2626' },
        { value: 'rose', label: 'Rose', hex: '#f43f5e' },
        { value: 'sky', label: 'Sky', hex: '#0ea5e9' },
        { value: 'success', label: 'Success', hex: '#16a34a' },
        { value: 'teal', label: 'Teal', hex: '#14b8a6' },
        { value: 'violet', label: 'Violet', hex: '#8b5cf6' },
        { value: 'warning', label: 'Warning', hex: '#f59e0b' },
        { value: 'white', label: 'White', hex: '#ffffff' },
        { value: 'yellow', label: 'Yellow', hex: '#eab308' }
      ];
    });

    // Toast Functions
    const showToast = (type: string, title: string, message: string, duration = 5000) => {
      const id = Date.now() + Math.random();
      const toast = { id, type, title, message, removing: false };
      toasts.value.push(toast);
      
      setTimeout(() => {
        removeToast(id);
      }, duration);
    };
    
    const removeToast = (id: number) => {
      const toast = toasts.value.find(t => t.id === id);
      if (toast) {
        toast.removing = true;
        setTimeout(() => {
          const index = toasts.value.findIndex(t => t.id === id);
          if (index > -1) {
            toasts.value.splice(index, 1);
          }
        }, 300);
      }
    };

    // API Helper Functions using ChurchTools client
    const apiRequest = async (endpoint: string, options: any = {}) => {
      try {
        if (options.method === 'POST') {
          return await churchtoolsClient.post(endpoint, options.body);
        } else if (options.method === 'PUT') {
          return await churchtoolsClient.put(endpoint, options.body);
        } else if (options.method === 'DELETE') {
          return await churchtoolsClient.delete(endpoint);
        } else {
          return await churchtoolsClient.get(endpoint);
        }
      } catch (error) {
        console.error('API request failed:', error);
        throw error;
      }
    };

    // Authentication functions
    const login = async () => {
      if (!loginForm.baseUrl || !loginForm.username || !loginForm.password) {
        loginError.value = 'Please fill in all fields';
        return;
      }

      isLoading.value = true;
      loginError.value = '';
      loginStatus.value = 'Connecting to ChurchTools...';

      try {
        churchtoolsClient.setBaseUrl(loginForm.baseUrl);
        
        const response = await churchtoolsClient.post('/login', {
          username: loginForm.username,
          password: loginForm.password
        });

        if (response.status === 'success') {
          isAuthenticated.value = true;
          currentUser.value = `${response.data.firstName} ${response.data.lastName}`;
          apiToken.value = response.data.token;
          personId.value = response.data.personId;
          
          showToast('success', 'Login Successful', `Welcome, ${currentUser.value}!`);
          await loadTags();
        } else {
          throw new Error('Login failed');
        }
      } catch (error) {
        console.error('Login error:', error);
        loginError.value = 'Login failed. Please check your credentials and try again.';
        showToast('error', 'Login Failed', 'Please check your credentials and try again.');
      } finally {
        isLoading.value = false;
        loginStatus.value = '';
      }
    };

    const logout = () => {
      isAuthenticated.value = false;
      currentUser.value = '';
      apiToken.value = '';
      personId.value = null;
      tags.value = [];
      selectedTags.value = [];
      loginForm.username = '';
      loginForm.password = '';
      showToast('info', 'Logged Out', 'You have been logged out successfully.');
    };

    // Tag management functions
    const loadTags = async () => {
      if (!isAuthenticated.value) return;

      isLoadingTags.value = true;
      tagError.value = '';

      try {
        const response = await apiRequest('/tags');
        tags.value = response.data || [];
        showToast('success', 'Tags Loaded', `Loaded ${tags.value.length} tags successfully.`);
      } catch (error) {
        console.error('Error loading tags:', error);
        tagError.value = 'Failed to load tags. Please try again.';
        showToast('error', 'Load Failed', 'Failed to load tags. Please try again.');
      } finally {
        isLoadingTags.value = false;
      }
    };

    // Initialize when in ChurchTools environment
    onMounted(async () => {
      if (import.meta.env.MODE === 'production' && window.settings?.base_url) {
        // In production (ChurchTools environment), try to get current user
        try {
          const user = await churchtoolsClient.get('/whoami');
          if (user.data) {
            isAuthenticated.value = true;
            currentUser.value = `${user.data.firstName} ${user.data.lastName}`;
            personId.value = user.data.id;
            await loadTags();
          }
        } catch (error) {
          console.log('Not authenticated in ChurchTools environment');
        }
      }
    });

    return {
      // State
      isAuthenticated,
      currentUser,
      isLoading,
      isLoadingTags,
      isSaving,
      loginError,
      loginStatus,
      tagError,
      selectedType,
      showCreateForm,
      editingTag,
      selectedTags,
      prefixFilter,
      bulkColor,
      isBulkOperating,
      showBulkColorDropdown,
      showTagColorDropdown,
      showColorPicker,
      colorPickerTarget,
      selectedColorInPicker,
      sortField,
      sortDirection,
      toasts,
      loginForm,
      tagForm,
      tags,
      
      // Computed
      allSelected,
      sortedTags,
      colorOptions,
      
      // Methods
      showToast,
      removeToast,
      login,
      logout,
      loadTags
    };
  }
}).mount('#app');